import * as studentAnswer from './studentAnswer'

export default {
  studentAnswer,
}
